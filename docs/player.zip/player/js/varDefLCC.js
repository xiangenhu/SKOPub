
// LCC added
var lccurl=qs("lccurl","https://dsspp.x-in-y.com/lcc");
var LCCSessionKey = "";
// LCC added
